package albums;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ApplicationFactory
{
	private AlbumsByArtistApp albumsByArtistApp = null;
	
	public AlbumsByArtistApp createAlbumsByArtistApp(String csvFileText, String collectionName)
	{
		// using the Strategy Pattern could reference a config file here to determine the correct DbHandler
		DbHandler mongoDBHandler = new MongoDbHandler(csvFileText, collectionName);
		
		// treat the AlbumsByArtistApp like a singleton.
		if (albumsByArtistApp == null)
		{
			albumsByArtistApp = new AlbumsByArtistApp(mongoDBHandler);
		}
		
		return albumsByArtistApp;
	}
	
	public static void main(String[] args)
	{
		ApplicationFactory applicationFactory = new ApplicationFactory();
		
		// first create the application...
		// make sure the albums.txt string argument includes the location on the target machine.
		// albumsByArtist is the name of the collection.
		AlbumsByArtistApp albumsByArtist = 
				applicationFactory.createAlbumsByArtistApp("/Users/macuser/Documents/albums.txt", "albumsByArtist");
		
		// get list of albums by artist
		String artist = "The Beatles";
		List<String> albums = albumsByArtist.listOfAlbumsByArtist(artist);
		System.out.println("Albums by artist = " +artist);
		System.out.println(albums +"\n");
		
		// get genres ranked by number of albums.
		StringBuilder stringBuilder = new StringBuilder();
		Map<String, Integer> genres = albumsByArtist.getGenresRankedByNumberOfAlbums();
		Set<String> genre = genres.keySet();
		
		Iterator<String> genreIterator = genre.iterator();
		while (genreIterator.hasNext())
		{
			String name = genreIterator.next();
			stringBuilder.append(name);
			stringBuilder.append(": ");
			Integer number = genres.get(name);
			stringBuilder.append(number);
			stringBuilder.append("\n");
		}
		
		System.out.println("Genre Ranked by number of albums.");
		System.out.println(stringBuilder.toString());
		
		// get years with most albums based on a threshold.
		int threshold = 4; // threshold for the years for the most albums.
		
		stringBuilder = new StringBuilder();
		Map<String, Integer> mostAlbumsYears = albumsByArtist.getYearsWithMostAlbums(threshold);
		Set<String> years = mostAlbumsYears.keySet();
		
		Iterator<String> yearsIterator = years.iterator();
		while (yearsIterator.hasNext())
		{
			String year = yearsIterator.next();
			stringBuilder.append(year);
			stringBuilder.append(": ");
			Integer number = mostAlbumsYears.get(year);
			stringBuilder.append(number);
			stringBuilder.append("\n");
		}
		
		System.out.println("Years with most albums by threshold = " +threshold);
		System.out.println(stringBuilder.toString());
		
	}

}
