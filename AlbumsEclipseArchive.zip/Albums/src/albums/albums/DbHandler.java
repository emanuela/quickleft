package albums;

import java.util.List;
import java.util.Map;

public interface DbHandler
{
	/**
	 * getAlbumsByArtist()
	 * @param artist
	 * @return list of albums by the given artist
	 */
	public List<String> getAlbumsByArtist(String artist);
	
	/**
	 * getGenresRankedByNumberOfAlbums()
	 * @return a map from genre to number of albums.
	 */
	public Map<String, Integer> getGenresRankedByNumberOfAlbums();
	
	/**
	 * getYearsWithMostAlbums(int threshold)
	 * @return a map from year to number of albums based on a threshold.
	 */
	public Map<String, Integer> getYearsWithMostAlbums(int threshold);
}
