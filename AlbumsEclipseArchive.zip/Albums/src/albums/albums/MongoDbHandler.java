package albums;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;

public class MongoDbHandler implements DbHandler
{
	private static final String FIELD_SEPARATER = ";";
	
	private String collectionName;
	private String csvFile;
	protected DB mongoDb = null;
	
	public MongoDbHandler(String csvFile, String collectionName)
	{
		this.collectionName = collectionName;
		this.csvFile = csvFile;
		createDb();
	}
	
	public List<String> getAlbumsByArtist(String artist)
	{
		List<String> listOfAlbums = new ArrayList<>();
		
		DBCollection collection = mongoDb.getCollection(collectionName);
		
		BasicDBObject query = new BasicDBObject("artist", artist);
		DBCursor cursor = collection.find();
        cursor = collection.find(query);
        
		try
		{
			while (cursor.hasNext())
			{
				DBObject dbObject = cursor.next();
				String album = (String) dbObject.get("album");
//				System.out.println(album);
				listOfAlbums.add(album);
			}
		} catch (Exception e)
		{
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		} finally
		{
			cursor.close();
		}
		
		return listOfAlbums;
	}
	
	// method for debug
	private Map<String, Integer> getYearsWithMostAlbums()
	{
		Map<String, Integer> yearsMap = new HashMap<>();
		
		findByField("year", yearsMap);
		
		Map<String, Integer> result = sortByValue(yearsMap);
		return result;
	}
	
	public Map<String, Integer> getYearsWithMostAlbums(int threshold)
	{
		if (threshold < 1)
		{
			threshold = 1;
		}
		
		Map<String, Integer> yearMap = new HashMap<>();
		
		findByField("year", yearMap);
		
		Map<String, Integer> result = sortByValue(yearMap);
		
		Map<String, Integer> thresholdResult = new HashMap<>();
		Set<String> keySet = result.keySet();
		
		Iterator<String> keyIterator = keySet.iterator();
		while (keyIterator.hasNext())
		{
			String year = keyIterator.next();
			Integer numberOfAlbums = yearMap.get(year);
			if (numberOfAlbums >= threshold)
			{
				thresholdResult.put(year, numberOfAlbums);
			}
			else
			{
				continue;
			}
		}
		result = sortByValue(thresholdResult);
		return result;
	}
	
	public Map<String, Integer> getGenresRankedByNumberOfAlbums()
	{
		Map<String, Integer> genreMap = new HashMap<>();
		
		findByField("genre", genreMap);
		
		Map<String, Integer> result = sortByValue(genreMap);
		return result;
	}

	private void findByField(String searchField, Map<String, Integer> inputMap)
	{
		DBCollection collection = mongoDb.getCollection("albumsByArtist");
		DBCursor cursor = collection.find();
		
		try
		{
			while (cursor.hasNext())
			{
				DBObject dbObject = cursor.next();
				String field = (String) dbObject.get(searchField);
				
				// Debug
//				System.out.println("field: " +field);
				
				if (inputMap.containsKey(field))
				{
					int sum = inputMap.get(field);
					inputMap.put(field, sum + 1);
				}
				else
				{
					inputMap.put(field, 1);
				}
				
			}
		} 
		catch (Exception e)
		{
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		} finally
		{
			cursor.close();
		}
		
		// Debug
//		System.out.println("printing inputMap");
//		System.out.println("genreMap: " +inputMap);
	}
	
	// function to sort hash map by values 
    private Map<String, Integer> sortByValue(Map<String, Integer> hashMap) 
    { 
    	Set<Entry<String, Integer>> enrtrySet = hashMap.entrySet();
 
        // Create a list from elements of HashMap 
        List<Map.Entry<String, Integer> > list = 
               new LinkedList<Map.Entry<String, Integer> >(enrtrySet); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<String, Integer> >() { 
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) 
            { 
                return (o2.getValue()).compareTo(o1.getValue()); 
            } 
        }); 
          
        // put data from sorted list to hash map  
        HashMap<String, Integer> retrunHashMap = new LinkedHashMap<String, Integer>();
        
        for (Map.Entry<String, Integer> entry : list) { 
            retrunHashMap.put(entry.getKey(), entry.getValue()); 
        } 
        return retrunHashMap; 
    } 
	
	private void createDb() 
	{
		BufferedReader buffReader = null;
		DBCollection collection = null;
		String line = null;
		
        try 
        { 
        	buffReader = new BufferedReader(new FileReader(csvFile));
        	
        	// skip first header line
        	line = buffReader.readLine();
        	
        	mongoDb = createMongoDbClient();
        	collection = mongoDb.getCollection("albumsByArtist");
        	
			if (!collectionExists("albumsByArtist"))
			{

				while ((line = buffReader.readLine()) != null)
				{
					// System.out.println("line from buffReader: " +line);
					String[] albumData = line.split(FIELD_SEPARATER);

					// Debug
					// System.out.println(albumData[0]);
					// System.out.println(albumData[1]);
					// System.out.println(albumData[2]);
					// System.out.println(albumData[3]);

					BasicDBObject doc = new BasicDBObject("album", "albumsDb").append("album", albumData[0])
							.append("artist", albumData[1]).append("genre", albumData[2]).append("year", albumData[3]);

					collection.insert(doc);
				}
			}
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (buffReader != null) {
                try {
                    buffReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        
        // create an index on the artist field.
        collection.createIndex("artist");
        collection.find(); // switch this line with the following if you want the debug output.
        
        // Debug output
//        DBCursor cursorDocMap = collection.find();    // the line to switch with the preceding line. 
        
//    	while (cursorDocMap.hasNext()) {
//    		System.out.println(cursorDocMap.next());
//    	}
    }
	
	private boolean collectionExists(final String collectionName) {
	    Set<String> collectionNames = mongoDb.getCollectionNames();
	    for (final String name : collectionNames) {
	        if (name.equalsIgnoreCase(collectionName)) {
	            return true;
	        }
	    }
	    return false;
	}

	private DB createMongoDbClient()
	{
		  // Creating a Mongo client 
	      MongoClient mongoClient = new MongoClient("localhost" , 27017); 
	   
	      // Creating Credentials 
	      MongoCredential credential; 
	      credential = MongoCredential.createCredential("sampleUser", "albumsDb", "password".toCharArray()); 
	      System.out.println("Connected to the database successfully");  
	      
	      // Accessing the database 
	      DB db = mongoClient.getDB("albumsDb");
	      System.out.println("Credentials ::"+ credential);
	      
	      return db;
	} 
	
	public static void main(String[] argv)
	{
		MongoDbHandler dbHandler = 
				new MongoDbHandler("/Users/macuser/Documents/albums.txt", "albumsByArtist");
		if (dbHandler.mongoDb.getCollectionNames() != null)
		{
			System.out.println("Database successfully created.");
		}
		
		Map<String, Integer> returnMap = dbHandler.getYearsWithMostAlbums();
		
		// print the sorted hash map 
		for (Map.Entry<String, Integer> en : returnMap.entrySet()) { 
			System.out.println("Key = " + en.getKey() +  
					", Value = " + en.getValue()); 
		} 
	}
}
