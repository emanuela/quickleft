package albums;

import java.util.List;
import java.util.Map;

public class AlbumsByArtistApp
{
	DbHandler dbHandler;
	
	public AlbumsByArtistApp(DbHandler dbHandler)
	{
		this.dbHandler = dbHandler;
	}
	
	public List<String> listOfAlbumsByArtist(String artist)
	{
		return dbHandler.getAlbumsByArtist(artist);
	}
	
	/**
	 * getGenresRankedByNumberOfAlbums()
	 * @return a map of genres to number of albums.
	 */
	public Map<String, Integer> getGenresRankedByNumberOfAlbums()
	{
		return dbHandler.getGenresRankedByNumberOfAlbums();
	}
	
	/**
	 * getYearsWithMostAlbums(int threshold)
	 * @param threshold
	 * @return a map of years with corresponding number of albums.
	 */
	public Map<String, Integer> getYearsWithMostAlbums(int threshold)
	{
		return dbHandler.getYearsWithMostAlbums(threshold);
	}

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

}
